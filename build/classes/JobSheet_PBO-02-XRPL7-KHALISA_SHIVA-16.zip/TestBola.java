
package bus;

public class TestBola {
    public static void main (String [] args){
        Bola TestBola = new Bola();
        TestBola.setjarijari(14);
        TestBola.setdiameter();
        TestBola.setphi(3.14);
        TestBola.showluaspermukaan(0);
        TestBola.showvolume(0);
        
        
    }
    
}
